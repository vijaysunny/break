package summm;

import javax.swing.JPanel;

public class Bre extends JPanel {

	/**
	 * Create the panel.
	 */
	public Bre() {

	}

}
