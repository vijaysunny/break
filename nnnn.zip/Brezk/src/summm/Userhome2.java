package summm;



import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.TextField;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JTextField;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Cursor;
import java.awt.Font;

import javax.swing.border.BevelBorder;
import javax.swing.border.MatteBorder;

import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.border.TitledBorder;
import javax.swing.UIManager;
import javax.swing.border.CompoundBorder;

import summm.Log;

import javax.swing.SwingConstants;

import java.awt.SystemColor;
import java.awt.event.MouseMotionAdapter;



import javax.swing.JComboBox;

import com.sun.glass.ui.Window;

public class Userhome2 extends JFrame {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4665588170776421191L;

	private JPanel contentPane;
	
	public static JTextField namee;
	public static JTextField idd;
int xmouse,ymouse;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Userhome2 frame = new Userhome2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @param <showMessageDialog>
	 */
	public <showMessageDialog> Userhome2() {
		setTitle("Break");
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 564, 390);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 564, 379);
		contentPane.add(panel);
		panel.setLayout(null);
		ButtonGroup G=new ButtonGroup();
		
		JButton btnLogout = new JButton("Logout");
		btnLogout.setBackground(Color.RED);
		btnLogout.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnLogout.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				dispose();
				System.exit(0
						);
				
			}
		});
		btnLogout.setBounds(245, 265, 115, 33);
		panel.add(btnLogout);
		
		JPanel panel_1 = new JPanel();
		panel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent evt) {
				xmouse=evt.getXOnScreen();
				ymouse=evt.getYOnScreen();
				
			}
		});
		panel_1.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
				int x=e.getXOnScreen();
				int y=e.getYOnScreen();
				setLocation(x-xmouse,y-ymouse);
			}
		});
		panel_1.setBackground(SystemColor.activeCaption);
		panel_1.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		panel_1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		panel_1.setBounds(0, 0, 564, 52);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel labelmin = new JLabel("-");
		labelmin.setFont(new Font("Tahoma", Font.BOLD, 30));
		labelmin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		labelmin.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				setState(JFrame.ICONIFIED);
			}
		});
		labelmin.setBounds(434, 11, 46, 30);
		panel_1.add(labelmin);
		
		JLabel lblclose = new JLabel("X");
		lblclose.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblclose.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				dispose();
			}
		});
		lblclose.setBounds(490, 11, 62, 30);
		panel_1.add(lblclose);
		
		JLabel lblNewLabel = new JLabel("BREAK REMINDER \r\n\r\n");
		lblNewLabel.setBackground(SystemColor.activeCaption);
		lblNewLabel.setBounds(65, -16, 259, 95);
		panel_1.add(lblNewLabel);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		
		JButton btnFeedback = new JButton("Feedback");
		btnFeedback.setBackground(new Color(255, 222, 173));
		btnFeedback.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnFeedback.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				Feedback fe=new Feedback();
				fe.setVisible(true);
				fe.setLocationRelativeTo(null);
			}
		});
		btnFeedback.setBounds(21, 277, 115, 33);
		panel.add(btnFeedback);
		
		namee = new JTextField();
		namee.setSelectionColor(SystemColor.controlShadow);
		namee.setBackground(SystemColor.control);
		namee.setBounds(10, 151, 149, 33);
		namee.setFont(new Font("Tahoma",Font.BOLD,14));
		panel.add(namee);
		namee.setColumns(10);
		namee.setEditable(false);
		idd = new JTextField();
		idd.setSelectionColor(SystemColor.controlShadow);
		idd.setBackground(SystemColor.control);
		idd.setBounds(10, 217, 149, 33);
		idd.setFont(new Font("Tahomal",Font.BOLD,14));
		panel.add(idd);
		idd.setColumns(10);
		idd.setEditable(false);
		
		JLabel lblUserProfile = new JLabel("Profile");
		lblUserProfile.setHorizontalAlignment(SwingConstants.CENTER);
		lblUserProfile.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblUserProfile.setBounds(10, 77, 138, 52);
		panel.add(lblUserProfile);
		
		JTextArea txtrWelcome = new JTextArea();
		txtrWelcome.setEditable(false);
		txtrWelcome.setFont(new Font("Tahoma", Font.BOLD, 18));
		txtrWelcome.setBackground(Color.WHITE);
		txtrWelcome.setWrapStyleWord(true);
		txtrWelcome.setText("      Welcome \r\n           To\r\n  Break Reminder\r\n");
		txtrWelcome.setBounds(233, 118, 216, 83);
		panel.add(txtrWelcome);
		
		JLabel lblClickStartSession = new JLabel("Click logout to stop session\r\n");
		lblClickStartSession.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblClickStartSession.setBounds(233, 212, 297, 42);
		panel.add(lblClickStartSession);
		
		
		
		
	}
}
